package handler;

import http.HspRequest;
import http.HspResponse;
import servlet.HspCalServlet;
import servlet.HspHttpServlet;
import tomcat.HspTomcatV3;
import utils.WebUtils;

import java.io.*;
import java.net.Socket;

/**
 * @author xuchuanlei
 * @version 1.0
 * 将socket单独创建一个线程管理socket通信
 */
public class HspRequestHandler implements Runnable{

    private Socket socket=null;
    //构造器声明
    public HspRequestHandler(Socket socket) {
        this.socket = socket;
    }

//    这里我们可以对客户端/游览器进行io编程/交互
    @Override
    public void run()  {
        try {
//            InputStream inputStream = this.socket.getInputStream();
//            将字节流转换为字符流
//            BufferedReader bufferedReader = new BufferedReader(
//                    new InputStreamReader(inputStream, "UTF-8"));

            System.out.println("the current TheadId is "+Thread.currentThread().getId());


//            先硬编码
            HspRequest hspRequest = new HspRequest(socket.getInputStream());
            String num1 = hspRequest.getParameter("num1");
            String num2 = hspRequest.getParameter("num2");
            String uri = hspRequest.getUri();
            String method = hspRequest.getMethod();
            System.out.println("请求的参数num1= " + num1);
            System.out.println("请求的参数num2= " + num2);
            System.out.println("请求的uri地址= "+uri);
            System.out.println("请求的method= "+method);
            System.out.println("hspRequest= " + hspRequest);

//            String mes = null;
//            while ((mes = bufferedReader.readLine()) != null) {
//                if(mes.length()==0){
//                    break;
//                }
//                System.out.println(mes);
//            }
//
            //构建响应信息
            HspResponse hspResponse = new HspResponse(socket.getOutputStream());
//            String reps = HspResponse.respHeader + "hi, best myDiyTomcat!!!!!!!";
//            OutputStream outputStream = hspResponse.getOutputStream();
//            outputStream.write(reps.getBytes());
//            outputStream.flush();
//            outputStream.close();

//            HspCalServlet hspCalServlet = new HspCalServlet();
//            hspCalServlet.doPost(hspRequest, hspResponse);

            if(WebUtils.isHtml(uri)) {//就是静态页面
                String content = WebUtils.readHtml(uri.substring(1));
                content = HspResponse.respHeader + content;
                //得到outputstream , 返回信息(静态页面)给浏览器
                OutputStream outputStream = hspResponse.getOutputStream();
                outputStream.write(content.getBytes());
                outputStream.flush();
                outputStream.close();
                socket.close();
                return;
            }

            String servletName = HspTomcatV3.servletUrlMapping.get(uri);
            if (servletName == null) {
                servletName = "";
            }



            HspHttpServlet hspCalServlet = HspTomcatV3.servletMapping.get(servletName);
            if (hspCalServlet != null) {
                hspCalServlet.service(hspRequest, hspResponse);
            }else {
                //没有这个servlet , 返回404的提示信息
                String resp = HspResponse.respHeader + "<h1>404 Not Found</h1>";
                OutputStream outputStream = hspResponse.getOutputStream();
                outputStream.write(resp.getBytes());
                outputStream.flush();
                outputStream.close();
            }



//
//            BufferedWriter bufferedWriter = new BufferedWriter(
//                    new OutputStreamWriter(outputStream, "UTF-8"));
//            //消息头
//            String respHeader = "HTTP/1.1 200 OK\r\n"+
//                    "Content-Type:text/html;charset=utf-8\r\n\r\n"; //注意这里的换行
////            消息体
//            String resp= respHeader+ "hi, myDiyTomcat!!!!!!!"; //响应体
//
////            outputStream.write(resp.getBytes());
//
//            bufferedWriter.write(resp);

//           安全关闭连接,记得flush(操作),BufferedWriter.close() 会隐式调用 outputStream.close()，
//           不需要再手动关闭 outputStream
//           同样道理，BufferedReader.close() 也会关闭 inputStream
//           outputStream.flush();
//           bufferedWriter.flush();
//            outputStream.close();
//            bufferedWriter.close();
//            inputStream.close();
            socket.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally{
            if(socket!=null){
                try {
                    socket.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

}
