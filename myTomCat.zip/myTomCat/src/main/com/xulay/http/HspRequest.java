package http;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;

/**
 * @author xuchuanlei
 * @version 1.0
 * description 封装http请求为我们自定义servlet的请求信息类型(切面编程思想)
 */
public class HspRequest {
    private String method;
    private String uri;

//    存放参数列表 参数名-参数值 =》Hashmap
    private HashMap<String, String> parametersMapping=
        new HashMap<>();
    private InputStream inputStream=null;

//    消息体调用构造器封装
    public HspRequest(InputStream inputStream) {
        this.inputStream = inputStream;

//        封装的具体操作，即解析http请求
        encapHttpRequest();

    }

    private void encapHttpRequest() {
        System.out.println("HspRequest init()");
        try {
//            获取字符流
            BufferedReader bufferedReader = new BufferedReader(
                    new InputStreamReader(inputStream,"utf-8"));

//          数据示例
//          GET /hspCalServlet?num1=10&num2=30 HTTP/1.1
//          GET /hspCalServlet?num1=10&num2=30 HTTP/1.1
//          GET /?num1=10&num2=10 HTTP/1.1
//          Host: localhost:8080
//          读取第一行，先解析method方法
            String requestLine = bufferedReader.readLine();
            String[] requestLineArr = requestLine.split(" ");
            method = requestLineArr[0];

//            在解析uri有无参数列表
            int index = requestLineArr[1].indexOf("?");
            if (index == -1) {
                uri = requestLineArr[1];
            }else {
//                有参数列表进行进一步处理
                uri = requestLineArr[1].substring(0, index);
                //获取参数列表->parametersMapping
                //parameters => num1=10&num2=30
                String parameters = requestLineArr[1].substring(index+1);
                String[] parametersPair = parameters.split("&");
//                鲁棒性的判断
                if (null != parametersPair && !"".equals(parametersPair)) {
//                    再次分割
                    for (String parameterPair : parametersPair) {
                        String[] parameterVal = parameterPair.split("=");
                        if (parameterVal.length == 2) {
//                            放入hashmap
                            parametersMapping.put(parameterVal[0], parameterVal[1]);
                        }
                    }
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

//    获取参数值，根据参数名
    public String getParameter(String name) {
        if (parametersMapping.containsKey(name)) {
            return parametersMapping.get(name);
        }else {
            return "";
        }
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public HashMap<String, String> getParametersMapping() {
        return parametersMapping;
    }

    public void setParametersMapping(HashMap<String, String> parametersMapping) {
        this.parametersMapping = parametersMapping;
    }

    public InputStream getInputStream() {
        return inputStream;
    }

    public void setInputStream(InputStream inputStream) {
        this.inputStream = inputStream;
    }

    @Override
    public String toString() {
        return "HspRequest{" +
                "method='" + method + '\'' +
                ", uri='" + uri + '\'' +
                ", parametersMapping=" + parametersMapping +
                ", inputStream=" + inputStream +
                '}';
    }
}
