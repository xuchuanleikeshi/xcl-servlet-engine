package http;

import java.io.OutputStream;

/**
 * @author xuchuanlei
 * @version 1.0
 * description http响应消息的封装
 */
public class HspResponse {
    private OutputStream outputStream=null;
//    写一个消息头
    public static final String respHeader = "HTTP/1.1 200 OK\r\n" +
        "Content-Type:text/html;charset=utf-8\r\n\r\n";

//    在创建时传入对象，构造器
    public HspResponse(OutputStream outputStream) {
        this.outputStream = outputStream;


    }
    //获取输出流实例，完成消息传输
    public OutputStream getOutputStream() {
        return outputStream;
    }
}
