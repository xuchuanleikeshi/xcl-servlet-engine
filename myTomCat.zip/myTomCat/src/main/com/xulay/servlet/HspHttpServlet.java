package servlet;

import http.HspRequest;
import http.HspResponse;

import javax.servlet.http.HttpServlet;

/**
 * @author xuchuanlei
 * @version 1.0
 * description 抽象类，使用模板设计模式，重写service
 */
public abstract class HspHttpServlet implements HspServlet {
    @Override
    public void service(HspRequest request, HspResponse response) throws Exception {
//        利用多态的动态绑定机制，让doPost和doGet的实现交予我们的业务servlet子类
        if ("GET".equalsIgnoreCase(request.getMethod())) {
            this.doGet(request, response);
        }
        else if ("POST".equalsIgnoreCase(request.getMethod())) {
            this.doPost(request, response);
        }

    }

    public abstract void doGet(HspRequest request, HspResponse response);
    public abstract void doPost(HspRequest request, HspResponse response);

}
