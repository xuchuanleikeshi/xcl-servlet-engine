package servlet;

import http.HspRequest;
import http.HspResponse;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author xuchuanlei
 * @version 1.0
 * description 定义servlet接口，和init,doGet,doPost方法 (切面编程)
 */
public interface HspServlet {
    public void init() throws Exception;
    public void service(HspRequest request, HspResponse response) throws Exception;
    public void destroy();
}
