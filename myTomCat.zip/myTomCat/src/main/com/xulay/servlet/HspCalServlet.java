package servlet;

import http.HspRequest;
import http.HspResponse;
import utils.WebUtils;

import javax.servlet.http.HttpServlet;
import java.io.IOException;
import java.io.OutputStream;

/**
 * @author xuchuanlei
 * @version 1.0
 * description .......
 */
public class HspCalServlet extends HspHttpServlet {

    @Override
    public void doGet(HspRequest request, HspResponse response) {
//        实现我们的定制servlet逻辑
//        拿到请求并解析
        String num1 = request.getParameter("num1");
        String num2 = request.getParameter("num2");
        int num1_ = WebUtils.parseInt(num1,0);
        int num2_ = WebUtils.parseInt(num2,0);
        int sum = num1_ + num2_;

        OutputStream outputStream = response.getOutputStream();
        String respMes = HspResponse.respHeader
                + "<h1>" + num1 + " + " + num2 + " = " + sum + " HspTomcatV3 - 反射+xml创建</h1>";
        try {

            outputStream.write(respMes.getBytes());
            outputStream.flush();
            outputStream.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public void doPost(HspRequest request, HspResponse response) {
        doGet(request, response);
    }

    @Override
    public void init() throws Exception {

    }

    @Override
    public void destroy() {

    }
}
