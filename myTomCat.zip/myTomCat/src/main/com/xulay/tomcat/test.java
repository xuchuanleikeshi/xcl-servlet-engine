package tomcat;

/**
 * @author xuchuanlei
 * @version 1.0
 * description .......
 */
public class test {
    public static void main(String[] args) throws ClassNotFoundException {

        Class<?> aClass = Class.forName("servlet.HspCalServlet");

    }
}
