package tomcat;


import handler.HspRequestHandler;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.junit.Test;
import servlet.HspCalServlet;
import servlet.HspHttpServlet;


import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author xuchuanlei
 * @version 1.0
 * description 实现servlet与多线程关联，同时实现xml的动态类加载(封装+继承+多态+io+dom4j(xml配置文件读取))
 */
public class HspTomcatV3 {

//        类加载，通过xml解析得到类的全路径
//        定义映射类hashmap
        public static final ConcurrentHashMap<String, HspHttpServlet>
                     servletMapping = new ConcurrentHashMap<>();
        public static final ConcurrentHashMap<String,String>
                servletUrlMapping = new ConcurrentHashMap<>();

    public static void main(String[] args) throws Exception {
        HspTomcatV3 hspTomcatV3 = new HspTomcatV3();
        hspTomcatV3.init();
        hspTomcatV3.run();
    }

    public void run() throws Exception {
        //在8080端口监听
        ServerSocket serverSocket = new ServerSocket(8080);
        System.out.println("=======hsptomcatV2 在8080监听=======");
        //只要 serverSocket没有关闭，就一直等待浏览器/客户端的连接

        while (!serverSocket.isClosed()) {
            //1. 接收到浏览器的连接后，如果成功，就会得到socket
            //2. 这个socket 就是 服务器和 浏览器的数据通道
            Socket socket = serverSocket.accept();
            //3. 创建一个线程对象，并且把socket给该线程
            //  这个是java线程基础
            HspRequestHandler hspRequestHandler =
                    new HspRequestHandler(socket);
            new Thread(hspRequestHandler).start();

        }

    }


//        对容器进行初始化
     public void init() throws Exception {
//        读取xml文件,利用dom4j工具,利用发射机制
        String resource = HspTomcatV3.class.getResource("/").getPath();
        System.out.println(resource);

        SAXReader saxReader = new SAXReader();
         try {
             Document read = saxReader.read(new File(resource + "web.xml"));
             System.out.println("xml=\t"+read);
//                得到根元素
             Element rootElement = read.getRootElement();
//             获取根元素下面的所有子元素
             List<Element> element = rootElement.elements();
//             遍历
             for(Element e:element){

                 if ("servlet".equals(e.getName())){
//                     确保这是一个servlet配置
//                     使用反射机制将该实例放入servletMapping
                     System.out.println("发现现有的servlet!!!!!");
                     Element elementName = e.element("servlet-name");
                     Element elementClass = e.element("servlet-class");


                     System.out.println( "类名:\t"+ elementName.getText());
                     System.out.println("类的全路径:\t"+elementClass.getText());
                     System.out.println("类的全路径:\t"+Class.forName(elementClass.getText().trim()));
                    servletMapping.put
                            (elementName.getText(),
                            (HspHttpServlet)Class.forName(elementClass.getText().trim()).newInstance());

                 } else if ("servlet-mapping".equals(e.getName())){
                     //这是一个servlet-mapping
                     System.out.println("发现 servlet-mapping");
                     Element servletName = e.element("servlet-name");
                     Element urlPatter = e.element("url-pattern");

                     System.out.println("映射名称：\t" + servletName.getText());
                     System.out.println(urlPatter.getText());
                     servletUrlMapping.put(urlPatter.getText(),servletName.getText());

                 }
             }

         } catch (Exception e) {
             throw new Exception(e);
         }

         //老韩验证，这两个容器是否初始化成功
         System.out.println("servletMapping= " + servletMapping);
         System.out.println("servletUrlMapping= " + servletUrlMapping);

     }
}