package tomcat;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author xuchuanlei
 * @version 1.0
 * 
 */
public class HspTomcatV1 {
    public static void main(String[] args) throws Exception {

//        创建ServerSocket，在8080端口监听
        ServerSocket serverSocket = new ServerSocket(8080);
        System.out.println("==========mytomcat在8080端口监听==========");
        while (!(serverSocket.isClosed()) ) {
//            等待浏览器和客户端连接
            Socket socket = serverSocket.accept();
//                接受数据浏览器的发送请求
            InputStream inputStream = socket.getInputStream();
//            转为字符流
            BufferedReader bufferedReader = new BufferedReader(
                    new InputStreamReader(inputStream,"utf-8"));
            String mes=null;
            System.out.println("========接受浏览器的发送数据===========");
            while ((mes = bufferedReader.readLine()) != null) {
                if (mes.length()==0){
                    break;
                }
                System.out.println(mes);
            }


//            组织响应头
            OutputStream outputStream = socket.getOutputStream();
//            构建响应头
            String respHeader = "HTTP/1.1 200 OK\r\n"+
                    "Content-Type:text/html;charset=utf-8\r\n\r\n"; //注意这里的换行
            String resp= respHeader+ "hi, myDiyTomcat!!!!!!!"; //响应体
            outputStream.write(resp.getBytes());//注意转换为字节流,byte[]返回
//            安全关闭
            outputStream.flush();
            outputStream.close();
            inputStream.close();
            socket.close();

        }
    }
}
